﻿namespace Ejercicio01;

class Area
{

    static double AreaTriangulo(double base1, double altura)
    {
        return (base1 * altura)/2;
    
    }
    static double AreaCuadrado(double lado)
    {
        return lado * lado;
    }
    static double AreaRectangulo(double baseR, double alturaR)
    {
        return baseR * alturaR;
    }
    static double AreaCirculo(double radio)
    {
        return Math.PI * Math.Pow(radio,2);
    }
}