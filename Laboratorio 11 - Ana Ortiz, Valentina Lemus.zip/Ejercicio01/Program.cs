﻿using Ejercicio01;

class Program
{
    static void Main(string[]args)
    {
        string opction;
        do{
            Console.WriteLine("-------------------");
            Console.WriteLine("       ÁREAS       ");
            Console.WriteLine("-------------------");
            Console.WriteLine("Triangulo:        A");
            Console.WriteLine("Cuadrado:         B");
            Console.WriteLine("Reactángulo:      C");
            Console.WriteLine("Círculo:          D");
            Console.WriteLine("-------------------");

            opction = Console.ReadLine();

            switch(opction)
            {
                case "A":
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine("Usted ha elegido calcular el Área de un Triangulo");
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine("Ingrese la base del triángulo:");
                    double base1 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese la altura del triángulo:");
                    double altura = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine($"El Área del Triángulo es: {(base1*altura)/2}");

                    break;
                case "B":
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine("Usted ha elegido calcular el Área de un Cuadrado");
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine("Ingrese el lado: ");
                    double lado = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine($"El Área del Triángulo es: {lado * lado}");

                    break;
                case "C":
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine("Usted ha elegido calcular el Área de un Rectangulo");
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine("Ingrese la base del Rectangulo:");
                    double baseR = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese la altura del Rectangulo:");
                    double alturaR = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine($"El Área del Triángulo es: {baseR * alturaR}");
                    break;
                case "D":
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine("Usted ha elegido calcular el Área de un Circulo");
                    Console.WriteLine("-------------------------------------------------");
                    Console.WriteLine("Ingrese el radio del Cirulo:");
                    double radio = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine($"El Área del Triángulo es: {Math.PI * Math.Pow(radio,2)}");
                    break;
                default:
                    Console.WriteLine("Saliendo del programa");
                    break;

            }      
        }while (opction != "E");

    }

}