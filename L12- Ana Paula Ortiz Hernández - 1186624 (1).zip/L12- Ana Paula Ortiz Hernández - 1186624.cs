using System.Formats.Asn1;
using System.Security.Cryptography.X509Certificates;

namespace  Lab_10_Ortiz_Hernandez;     

public class Circulo
{

private double radio;
    public Circulo(double rad){
         this.radio = rad;
    }
    private double ObtenerPerimetro ()
    {
        return 2*Math.PI*this.radio;
    }
        private  double ObtenerArea ()
    {
        return Math.PI*this.radio*Math.Pow(radio,2);
    }
        private double ObtenerVolumen ()
    {
        return  (4*Math.PI*radio*Math.Pow(radio,3)/3);
    }
    
        public void CalcularGeometria (ref double unPerimetro, ref double unArea, ref double unVolumen)
    {
        unPerimetro = ObtenerPerimetro();
        unArea = ObtenerArea ();
        unVolumen = ObtenerVolumen();
    }

    public double MostrarArea ()
    {
        return ObtenerArea();
    }

    public double MostrarVolumen()
    {
        return ObtenerVolumen();
    }
    public double MostrarPerimetro()
    {
        return ObtenerPerimetro();
    }
    
}