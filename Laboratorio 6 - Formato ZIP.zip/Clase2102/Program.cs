﻿using System.Diagnostics.Tracing;
using System.Runtime.CompilerServices;

class program   
{
    static void Main(string[] args)
    {
        int numeroMes;
        string entradaMes;
        string mesCadena;

        Console.WriteLine("Ingrese un  numero del 1 al 12 para mostrar el nombre del mes");
        entradaMes = Console.ReadLine();

        if(int.TryParse(entradaMes, out numeroMes))
        {
            //Se convierte el valor ingresado//
            //Try.Parse es para convertir el texto a numero//
        
        }
        else 
        {
            Console.WriteLine("Error, formato no valido, ingrese un numero del 1 al 12");
        }

        Console.WriteLine(numeroMes);
        switch(numeroMes)
        {
            case 1:

                mesCadena = "Enero";
                break;
            
            case 2:

                mesCadena = "Febrero";
                break;

            case 3:

                mesCadena = "Marzo";
                break;

            case 4:

                mesCadena = "Abril";
                break;

            case 5:

                mesCadena = "Mayo";
                break;

            case 6:

                mesCadena = "Junio";
                break;

            case 7:

                mesCadena = "Julio";
                break;
            
            case 8:

                mesCadena = "Agosto";
                break;
            
            case 9:

                mesCadena = "Septiembre";
                break;
            
            case 10:

                mesCadena = "Octubre";
                break;
            
            case 11:

                mesCadena = "Noviembre";
                break;
            
            case 12:

                mesCadena = "Diciembre";
                break;
            
            default:
                
                mesCadena = "";
                Console.WriteLine("Error, debe ingresar numeros del 1 al 12");
                break;

        }
        Console.WriteLine($"Mes: '{mesCadena}'");

        Console.WriteLine("Ejercicio 2");
        int numA;
        int numB;
        int numC;
        Console.WriteLine("Ingrese un numero entero");
        numA = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese un numero entero");
        numB = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese un numero entero");
        numC = Int32.Parse(Console.ReadLine());

        if(numA > numB)
        {
            if(numC > numA)
            {
                if(numA == numC)
                {
                    Console.WriteLine("(A=C)>B");
                }
                else
                {
                    Console.WriteLine("C > A > B");
                }
            }
            else if(numC < numA)
            {
                Console.WriteLine("A > C > B");
            }

        }
        else
        {
            if(numA == numB)
            {
                if(numA > numC)
                {
                    Console.WriteLine("(A=B)>C");
                }
                else
                {
                    if(numA == numC)
                    {
                        Console.WriteLine("A = C = B");
                    }
                    else
                    {
                        Console.WriteLine("C > (A=B)");
                    }
                    
                }
            }
            else
            {
                if(numB > numC)
                {
                    Console.WriteLine("B>C>A");
                }
                else
                {
                    if(numB == numC)
                    {
                        Console.WriteLine("(B=C)>A");
                    }
                    else
                    {
                        Console.WriteLine("C>B>A");
                    }
                }
            }
        } 

        Console.WriteLine("Tarea 'Signos Zodiacales'");
        int dia;
        int nacimiento;
        Console.WriteLine("Ingrese su año de nacimiento");
        nacimiento = Int32.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese su dia de nacimiento, ejemplo: 1, 3, 15, 31");
        dia = Int32.Parse (Console.ReadLine());
        
        int mes;
        string entradames;
        string mescadena;

        Console.WriteLine("Ingrese un  numero del 1 al 12 acorde a su mes de nacimiento");
        entradames = Console.ReadLine();

        if(int.TryParse(entradames, out mes))
        {
            //Se convierte el valor ingresado//
            //Try.Parse es para convertir el texto a numero//
        
        }
        else 
        {
            Console.WriteLine("Error, formato no valido, ingrese un numero del 1 al 12");
        }

        Console.WriteLine(mes);
        switch(mes)
        {
            case 1:

                mescadena = "Enero";
                if(dia > 0 && dia < 20 )
                {
                    Console.WriteLine("Su signo zodiacal es Capricornio");
                }
                else if(dia > 19 && dia < 32)
                {
                    Console.WriteLine("Su signo zodiacal es Acuario");
                }
                else
                {
                    Console.WriteLine("Error, enero no tiene mas de 31 dias");
                }
                break;
            
            case 2:

                mescadena = "Febrero";
                if(dia > 0 && dia < 19 )
                {
                    Console.WriteLine("Su signo zodiacal es Piscis");
                }
                else if(dia > 18 && dia < 31)
                {
                    Console.WriteLine("Su signo zodiacal es Acuario");
                }
                else
                {
                    Console.WriteLine("Error, Febrero no tiene mas de 30 dias");
                }
                break;

            case 3:

                mescadena = "Marzo";
                if(dia > 0 && dia < 22 )
                {
                    Console.WriteLine("Su signo zodiacal es Aries");
                }
                else if(dia > 19 && dia < 32)
                {
                    Console.WriteLine("Su signo zodiacal es Piscis");
                }
                else
                {
                    Console.WriteLine("Error, Marzo no tiene mas de 32 dias");
                }
                break;

            case 4:

                mescadena = "Abril";
                if(dia > 0 && dia < 21 )
                {
                    Console.WriteLine("Su signo zodiacal es Tauro");
                }
                else if(dia > 18 && dia < 32)
                {
                    Console.WriteLine("Su signo zodiacal es Aries");
                }
                else
                {
                    Console.WriteLine("Error, Abril no tiene mas de 31 dias");
                }
                break;

            case 5:

                mescadena = "Mayo";
                if(dia > 0 && dia < 21 )
                {
                    Console.WriteLine("Su signo zodiacal es Tauro");
                }
                else if(dia > 20 && dia < 32)
                {
                    Console.WriteLine("Su signo zodiacal es Geminis");
                }
                else
                {
                    Console.WriteLine("Error, Mayo no tiene mas de 32 dias");
                }
                break;

            case 6:

                mescadena = "Junio";
                if(dia > 0 && dia < 21 )
                {
                    Console.WriteLine("Su signo zodiacal es Geminis");
                }
                else if(dia > 20 && dia < 31)
                {
                    Console.WriteLine("Su signo zodiacal es Cancer");
                }
                else
                {
                    Console.WriteLine("Error, Junio no tiene mas de 31 dias");
                }
                break;

            case 7:

                mescadena = "Julio";
                if(dia > 0 && dia < 23 )
                {
                    Console.WriteLine("Su signo zodiacal es Cancer");
                }
                else if(dia > 22 && dia < 32)
                {
                    Console.WriteLine("Su signo zodiacal es Leo");
                }
                else
                {
                    Console.WriteLine("Error, Julio no tiene mas de 32 dias");
                }
                break;
            
            case 8:

                mescadena = "Agosto";
                if(dia > 0 && dia < 23 )
                {
                    Console.WriteLine("Su signo zodiacal es Leo");
                }
                else if(dia > 22 && dia < 32)
                {
                    Console.WriteLine("Su signo zodiacal es Virgo");
                }
                else
                {
                    Console.WriteLine("Error, Agosto no tiene mas de 32 dias");
                }
                break;
            
            case 9:

                mescadena = "Septiembre";
                if(dia > 0 && dia < 23 )
                {
                    Console.WriteLine("Su signo zodiacal es Virgo");
                }
                else if(dia > 22 && dia < 31)
                {
                    Console.WriteLine("Su signo zodiacal es Libra");
                }
                else
                {
                    Console.WriteLine("Error, Septiembre no tiene mas de 31 dias");
                }
                break;
            
            case 10:

                mescadena = "Octubre";
                if(dia > 0 && dia < 23 )
                {
                    Console.WriteLine("Su signo zodiacal es Libra");
                }
                else if(dia > 22 && dia < 32)
                {
                    Console.WriteLine("Su signo zodiacal es Escorpio");
                }
                else
                {
                    Console.WriteLine("Error, Octubre no tiene mas de 32 dias");
                }
                break;
            
            case 11:

                mescadena = "Noviembre";
                if(dia > 0 && dia < 22 )
                {
                    Console.WriteLine("Su signo zodiacal es Escorpio");
                }
                else if(dia > 23 && dia < 31)
                {
                    Console.WriteLine("Su signo zodiacal es Sagitario");
                }
                else
                {
                    Console.WriteLine("Error, Noviembre no tiene mas de 31 dias");
                }
                break;
            
            case 12:

                mescadena = "Diciembre";
                if(dia > 0 && dia < 22 )
                {
                    Console.WriteLine("Su signo zodiacal es Sagitario");
                }
                else if(dia > 21 && dia < 32)
                {
                    Console.WriteLine("Su signo zodiacal es Capricornio");
                }
                else
                {
                    Console.WriteLine("Error, Diciembre no tiene mas de 31 dias");
                }
                break;
            
            default:
                
                mescadena = "";
                Console.WriteLine("Error, debe ingresar numeros del 1 al 12");
                break;

        }


    }
}
