﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

int numero1;
int numero2;
int multiplicacion;
double division;
int suma;
int resta;

Console.WriteLine("Ingrese su nombre");
string nombre = Console.ReadLine();
Console.WriteLine("Hola" + "" + nombre);
Console.WriteLine("Ejercicio 1: operaciones aritmeticas");
Console.WriteLine("Ingrese un numero");
numero1 = Int32.Parse(Console.ReadLine());
Console.WriteLine("Ingrese un numero");
numero2 = Int32.Parse(Console.ReadLine());
suma = numero1 + numero2;
Console.WriteLine("Relsultado de la suma es" + " " + suma);
resta = numero1 - numero2;
Console.WriteLine("Relsultado de la resta es" + " " + resta);
multiplicacion = numero1 * numero1;
Console.WriteLine("Resultado de la multiplicacion es" + " " + multiplicacion);
division = numero1 / numero2;
Console.WriteLine("Resultado de la division es" + " " + division);


Console.WriteLine("Ejercicio 2: operaciones booleanas");

if (numero1 > numero2)
{
    Console.WriteLine(numero1 + ">" + numero2);
}
if (numero2 < numero1)
{
    Console.WriteLine(numero2 + "<" + numero1);
}
if (numero1 == numero2)
{
    Console.WriteLine(numero1 + "==" + numero2);
}

Console.WriteLine("Ejercicio 3: Jerarquia de operaciones");
int A;
int B;
int C;
int respuestaI;
int respuestaII;
double respuestaIII;
double respuestaIV;


Console.WriteLine("Ingrese un numero");
A = Int32.Parse(Console.ReadLine());
Console.WriteLine("Ingrese un numero");
B = Int32.Parse(Console.ReadLine());
Console.WriteLine("Ingrese un numero");
C = Int32.Parse(Console.ReadLine());
Console.WriteLine("Ingrese un numero");

respuestaI = A * B + C;
Console.WriteLine("Resultado de la operacion I es:" + respuestaI);
respuestaII = A * (B + C);
Console.WriteLine("Resultado de la operacion II es:" + respuestaII);
respuestaIII = A / B * C;
Console.WriteLine("Resultado de la operacion III es:" + respuestaIII);
respuestaIV = 3 * A + 2 * B / C * C;
Console.WriteLine("Resultado de la operacion IV es:" + respuestaIV);

Console.WriteLine("Ingrese el coeficiente a:");
double a = Convert.ToDouble(Console.ReadLine());


int y;
double discriminante;
int numerador;
int denominador;
int formula;

if (a == 0)
{
    Console.WriteLine("El coeficiente 'a' no puede ser igual a cero. La ecuación no es cuadrática.");
    return;
}
if (A > 0)
{
    y = (B * B) - (4 * A * C);
    if (y <= 0)
    {
        Console.WriteLine("Error, debe ser mayor a 0");
    }
    if (y > 0)
    {
        discriminante = Math.Sqrt(y);
        Console.WriteLine("El discriminante es:" + discriminante);
        numerador = (int)((-1 * B) + discriminante);
        denominador = (2 * A);
        formula = numerador / denominador;
        Console.WriteLine("El resultado de la formula cuadratica es:" + formula);

    }
}
    
