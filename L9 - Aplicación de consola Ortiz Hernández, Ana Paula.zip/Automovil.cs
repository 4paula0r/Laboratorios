

class Automovil
{
   private int modelo;
   private double precio;
   private string marca;
   private bool disponible;
   private double tipoCambioDolar;
   private double descuentoAplicado;
    public Automovil()
    {
     modelo = 2019;
     precio = 10000.00;
     marca =  "";
     disponible = false;
     tipoCambioDolar = 7.50;
     descuentoAplicado = 0.00;
    }

    
    public void unModelo;
    public void unModelo; 
    public double unPrecio;
    public string unaMarca;
    public double unTipoCambio; 
    public bool CambiarDisponibilidad;
    public string MostrarDisponibilidad;
    public string MostrarInformacion;
    public double miDescuento;


     public void DefinirModelo(int unModelo)
    {
        modelo = unModelo;
    }
    public void DefinirPrecio(double unPrecio)
    {
        precio = unPrecio;
    }
    public void DefinirMarca(string unaMarca)
    {
        marca = unaMarca;
    }
    public void DefinirTipoCambio(double unTipoCambio)
    {
        tipoCambioDolar = unTipoCambio;
    }
    public string ( Mostrardisponibilidad);
    {
        disponible = true;
        return "Disponible"

        disponible false;
        return "No se encuentra disponible por el momento";
    }
    public void ( string MostrarInformacion)
    {
        double precioDolares = precio / tipoCambioDolar;
        return “Marca: ” + [marca] + “. Modelo: ” + [modelo] + “. Precio de venta: Q” +
[precio] + “. Precio en dólares $” + [calcular precio en dólares] + “. ” +
MostrarDisponibilidad();
    }
    public void AplicarDescuento(double miDescuento)
    {
        descuentoAplicado = miDescuento;
        precio -= descuentoAplicado;
    }
}

