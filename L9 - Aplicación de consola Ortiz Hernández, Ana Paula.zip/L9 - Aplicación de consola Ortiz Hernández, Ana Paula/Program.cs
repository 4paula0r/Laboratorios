﻿// See https://aka.ms/new-console-template for more information

using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;


class Automovil
{
    static void Main(string[] args)
    {
        Automovil objAutomovil = new Automovil ();

        Console.WriteLine("Ingrese el modelo del automóvil");
        int modelo = int.Parse(Console.ReadLine());
        objAutomovil.unModelo(modelo);

        Console.WriteLine("Ingrese el precio del automóvil en quetzales:");
        double precio = double.Parse(Console.ReadLine());
        objAutomovil.unPrecio (precio);

        Console.WriteLine("Ingrese la marca del automóvil");
        string marca = string.Parse(Console.ReadLine());
        objAutomovil.unaMarca(marca);

        Console.WriteLine("Ingrese el tipo de dólares a quetzales:");
        double tipoCambioDolar = double.Parse(Console.ReadLine());
        objAutomovil.unTipoCambio(tipoCambioDolar);

        Console.WriteLine("Ingrese el tipo de dólares a quetzales:");
        double descuentoAplicado = double.Parse(Console.ReadLine());
        objAutomovil.miDescuento(descuentoAplicado);
    
        Console.WriteLine("Desea cambiar disponibilidad (Disponibilidad actual: " + objAutomovil.MostrarDisponibilidad() + ")? (T/F)");
        string respuesta = Console.ReadLine();
        if (respuesta.ToLower() == "t")
        {
            objAutomovil.MostrarDisponibilidad();
        }
    }
}
