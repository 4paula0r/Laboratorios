﻿// See https://aka.ms/new-console-template for more information
using System.Collections;
class Program
{
    static void Main(string[] args)
    {
        int opcion = 0;
        string entrada;

        do
        {
            Console.WriteLine("Menu");
            Console.WriteLine("1) sumatoria");
            Console.WriteLine("2) factorial");
            Console.WriteLine("3) tablas");
            Console.WriteLine("4) salida");
            Console.WriteLine("Ingrese un numero");
            entrada = Console.ReadLine();
            try
            {
                opcion = int.Parse(entrada);
            }
            catch (FormatException)
            {
                Console.WriteLine("Error, ingrese un numero");
            }

            switch (opcion)
            {
                case 1:
                    Console.WriteLine("Ingrese un numero positivo");
                    string entradaNumero = Console.ReadLine();
                    int n = 0;

                    try
                    {
                        n = int.Parse(entradaNumero);
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Error, ingrese un numero positivo");
                    }

                    int i = 1;
                    int sumatoria = 0;
                    while (i <= n)
                    {
                        sumatoria += 1;
                        i++;
                    }
                    Console.WriteLine("$Sumatoria: {sumatoria}");
                    break;

                case 2:
                    Console.WriteLine("Ingrese un numero positivo");
                    string entradaNumeroF = Console.ReadLine();
                    int nf = 0;

                    try
                    {
                        nf = int.Parse(entradaNumeroF);
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Error, ingrese un numero");
                    }

                    int j = 1;
                    int factorial = 1;
                    while (j <= nf)
                    {
                        factorial *= j;
                        j++;
                    }
                    Console.WriteLine("$Sumatoria: {factorial}");
                    break;

                case 3:
                    int multiplo;
                    string titulo ="\t";
                    for (int iTitulo = 1; iTitulo <= 10; iTitulo++)
                    {
                    titulo += iTitulo + "\t";
                    }
                    Console.WriteLine(titulo);
                  
                    string fila = "";
                    for (int iFila = 1; iFila <= 10; iFila++)
                    {
                        fila = iFila + "\t";
                         for (int multiplo = 1; multiplo <= 10; multiplo++)
                        {
                            fila += iFila * multiplo + "\t";
                        }
                        Console.WriteLine(fila);

                    }

                    break;
                case 4:
                    break;
                default:
                    Console.WriteLine("Error: ingrese un numero del 1 al 4");
                    break;
            }

        }
        while (opcion != 4);
    }
}

